from project.car import Car


class SportCar(Car):
    DEFAULT_FUEL_CONSUMPTION = fuel_consumption = 10

