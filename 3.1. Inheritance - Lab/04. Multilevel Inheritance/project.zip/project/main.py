from project.sports_car import SportsCar

the_car = SportsCar()
print(the_car.race())
print(the_car.drive())
