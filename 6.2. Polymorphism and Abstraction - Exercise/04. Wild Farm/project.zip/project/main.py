from project.animals.animal import Bird
from project.animals.animal import Mammal
from project.animals.birds import Owl, Hen
from project.food import Food, Meat, Vegetable, Fruit, Seed


